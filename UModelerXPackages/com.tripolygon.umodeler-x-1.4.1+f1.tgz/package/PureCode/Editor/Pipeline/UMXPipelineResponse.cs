using System;
using System.Threading.Tasks;
using Tripolygon.UModelerX.Editor.MCP;

namespace Tripolygon.UModelerX.Editor.Pipeline
{
    // UMXMcpResult 를 Unity Pipeline 서버의 응답 규약으로 변환한다.
    // 서버는 핸들러가 돌려준 값을 언제나 success:true 엔벌로프에 담으므로, 실패는 예외로 알려야
    // success:false 와 0 이 아닌 unity CLI 종료 코드가 나온다.
    static class UMXPipelineResponse
    {
        public static object Unwrap(UMXMcpResult result)
        {
            if (result == null)
            {
                throw new InvalidOperationException("The UModelerX operation returned no result.");
            }
            if (result.Success == false)
            {
                // UMXMcpResult.Fail 이 Message 를 "ERROR_CODE: detail" 로 만들어 두므로
                // 에러 코드가 엔벌로프의 error 문자열에 그대로 실린다.
                throw new InvalidOperationException(result.Message);
            }
            return new { message = result.Message, data = result.Data };
        }

        public static async Task<object> UnwrapAsync(Task<UMXMcpResult> task)
        {
            return Unwrap(await task);
        }
    }
}
