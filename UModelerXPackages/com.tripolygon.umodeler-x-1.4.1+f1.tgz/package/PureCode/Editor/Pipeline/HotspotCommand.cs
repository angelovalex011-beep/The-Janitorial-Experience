using Tripolygon.UModelerX.Editor.MCP;
using Unity.Pipeline.Commands;

namespace Tripolygon.UModelerX.Editor.Pipeline
{
    // Unity Pipeline 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXHotspotOperation 으로 위임.
    static class HotspotCommand
    {
        [CliCommand(
            "umx_hotspot_apply",
            UMXMcpUtility.HotspotToolDescription,
            Tags = new[] { "umodelerx/hotspot" })]
        public static object Apply(
            [CliArg("script", "Line-based UModelerX hotspot layout DSL script.", Required = true)]
            string script)
        {
            return UMXPipelineResponse.Unwrap(UMXHotspotOperation.Execute(script));
        }
    }
}
