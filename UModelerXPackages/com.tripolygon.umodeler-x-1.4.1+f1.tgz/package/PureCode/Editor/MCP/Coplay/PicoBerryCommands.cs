using System.Threading.Tasks;
using MCPForUnity.Editor.Tools;
using Newtonsoft.Json.Linq;

namespace Tripolygon.UModelerX.Editor.MCP.Coplay
{
    // CoplayDev MCP 용 PicoBerry 커맨드 5종.
    // 프로토콜 변환만 담당하고 실제 실행은 Core 의 PicoBerry*Operation 으로 위임한다.

    [McpForUnityTool("umx_picoberry_generate", Description = UMXPicoBerryToolText.GenerateDescription)]
    public static class PicoBerryGenerateCommand
    {
        // 중첩 Parameters 클래스가 없으면 스키마 properties 가 비어 파라미터 매핑이 안 되고
        // execute_custom_tool 경유가 강제된다 — ToolDiscoveryService 가 이 클래스에서 스키마를 추출한다.
        public class Parameters
        {
            [ToolParameter(UMXPicoBerryToolText.PromptParam)]
            public string prompt { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ImagePathParam)]
            public string imagePath { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ModelParam)]
            public string model { get; set; }

            [ToolParameter(UMXPicoBerryToolText.TextureParam)]
            public bool texture { get; set; }

            [ToolParameter(UMXPicoBerryToolText.HighResTextureParam)]
            public bool highResTexture { get; set; }

            [ToolParameter(UMXPicoBerryToolText.TPoseParam)]
            public bool tPose { get; set; }

            [ToolParameter(UMXPicoBerryToolText.PolygonCountParam)]
            public int polygonCount { get; set; }

            [ToolParameter(UMXPicoBerryToolText.NameParam)]
            public string name { get; set; }

            [ToolParameter(UMXPicoBerryToolText.PositionParam)]
            public string position { get; set; }

            [ToolParameter(UMXPicoBerryToolText.RotationParam)]
            public string rotation { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ScaleParam)]
            public string scale { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ParentParam)]
            public string parent { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();

            // texture 는 기본값이 true 다. bool? 로 읽어 미지정과 false 를 구별한다.
            var buildError = UMXPicoBerryRequestBuilder.BuildGenerate(
                prompt: @params["prompt"]?.ToString(),
                imagePath: @params["imagePath"]?.ToString(),
                model: @params["model"]?.ToString(),
                texture: @params["texture"]?.ToObject<bool?>() ?? true,
                highResTexture: @params["highResTexture"]?.ToObject<bool?>() ?? false,
                tPose: @params["tPose"]?.ToObject<bool?>() ?? false,
                polygonCount: @params["polygonCount"]?.ToObject<int?>() ?? 0,
                name: @params["name"]?.ToString(),
                position: @params["position"]?.ToString(),
                rotation: @params["rotation"]?.ToString(),
                scale: @params["scale"]?.ToString(),
                parent: @params["parent"]?.ToString(),
                out var request);

            if (buildError != null)
                return Task.FromResult(CoplayMcpAdapter.ToResponse(buildError));

            return UMXMcpUtility.RunOnMainThread<object>(
                () => CoplayMcpAdapter.ToResponse(PicoBerryGenerateOperation.Execute(request)));
        }
    }

    [McpForUnityTool("umx_picoberry_status", Description = UMXPicoBerryToolText.StatusDescription)]
    public static class PicoBerryStatusCommand
    {
        public class Parameters
        {
            [ToolParameter(UMXPicoBerryToolText.SessionIdParam)]
            public string sessionId { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();
            var request = new PicoBerryStatusRequest { SessionId = @params["sessionId"]?.ToString() };
            return UMXMcpUtility.RunOnMainThread<object>(
                () => CoplayMcpAdapter.ToResponse(PicoBerryStatusOperation.Execute(request)));
        }
    }

    [McpForUnityTool("umx_picoberry_wait", Description = UMXPicoBerryToolText.WaitDescription)]
    public static class PicoBerryWaitCommand
    {
        public class Parameters
        {
            [ToolParameter(UMXPicoBerryToolText.SessionIdParam, Required = true)]
            public string sessionId { get; set; }

            [ToolParameter(UMXPicoBerryToolText.TimeoutSecondsParam)]
            public int timeoutSeconds { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();
            var timeout = @params["timeoutSeconds"]?.ToObject<int?>() ?? 0;
            var request = new PicoBerryWaitRequest
            {
                SessionId = @params["sessionId"]?.ToString(),
                // 0 이하는 기본값으로 되돌린다. 클램프가 1초로 만들어 버리면 항상 타임아웃이 난다.
                TimeoutSeconds = timeout > 0 ? timeout : PicoBerryWaitRequest.DefaultTimeoutSeconds,
            };
            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => CoplayMcpAdapter.ToResponse(await PicoBerryWaitOperation.ExecuteAsync(request)));
        }
    }

    [McpForUnityTool("umx_picoberry_place", Description = UMXPicoBerryToolText.PlaceDescription)]
    public static class PicoBerryPlaceCommand
    {
        public class Parameters
        {
            [ToolParameter(UMXPicoBerryToolText.SessionIdParam)]
            public string sessionId { get; set; }

            [ToolParameter(UMXPicoBerryToolText.AssetIdParam)]
            public string assetId { get; set; }

            [ToolParameter(UMXPicoBerryToolText.NameParam)]
            public string name { get; set; }

            [ToolParameter(UMXPicoBerryToolText.PositionParam)]
            public string position { get; set; }

            [ToolParameter(UMXPicoBerryToolText.RotationParam)]
            public string rotation { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ScaleParam)]
            public string scale { get; set; }

            [ToolParameter(UMXPicoBerryToolText.ParentParam)]
            public string parent { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();

            var buildError = UMXPicoBerryRequestBuilder.BuildPlace(
                sessionId: @params["sessionId"]?.ToString(),
                assetId: @params["assetId"]?.ToString(),
                name: @params["name"]?.ToString(),
                position: @params["position"]?.ToString(),
                rotation: @params["rotation"]?.ToString(),
                scale: @params["scale"]?.ToString(),
                parent: @params["parent"]?.ToString(),
                out var request);

            if (buildError != null)
                return Task.FromResult(CoplayMcpAdapter.ToResponse(buildError));

            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => CoplayMcpAdapter.ToResponse(await PicoBerryPlaceOperation.ExecuteAsync(request)));
        }
    }

    [McpForUnityTool("umx_picoberry_list", Description = UMXPicoBerryToolText.ListDescription)]
    public static class PicoBerryListCommand
    {
        public class Parameters
        {
            [ToolParameter(UMXPicoBerryToolText.QueryParam)]
            public string query { get; set; }

            [ToolParameter(UMXPicoBerryToolText.PageParam)]
            public int page { get; set; }

            [ToolParameter(UMXPicoBerryToolText.LimitParam)]
            public int limit { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();
            var limit = @params["limit"]?.ToObject<int?>() ?? 0;
            var request = new PicoBerryListRequest
            {
                Query = @params["query"]?.ToString(),
                Page = @params["page"]?.ToObject<int?>() ?? 1,
                Limit = limit > 0 ? limit : PicoBerryListRequest.DefaultLimit,
            };
            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => CoplayMcpAdapter.ToResponse(await PicoBerryListOperation.ExecuteAsync(request)));
        }
    }
}
