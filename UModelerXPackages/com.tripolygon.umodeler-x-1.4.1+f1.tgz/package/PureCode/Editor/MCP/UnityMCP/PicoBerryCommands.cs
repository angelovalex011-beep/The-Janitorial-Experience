using System.Threading.Tasks;
using Unity.AI.MCP.Editor.Helpers;
using Unity.AI.MCP.Editor.ToolRegistry;

namespace Tripolygon.UModelerX.Editor.MCP
{
    public class PicoBerryGenerateParams
    {
        [McpDescription(UMXPicoBerryToolText.PromptParam)]
        public string Prompt { get; set; }

        [McpDescription(UMXPicoBerryToolText.ImagePathParam)]
        public string ImagePath { get; set; }

        [McpDescription(UMXPicoBerryToolText.ModelParam)]
        public string Model { get; set; }

        // 기본값 true 를 프로퍼티 초기화로 표현한다. 프레임워크는 미지정 필드를 건드리지 않는다.
        [McpDescription(UMXPicoBerryToolText.TextureParam)]
        public bool Texture { get; set; } = true;

        [McpDescription(UMXPicoBerryToolText.HighResTextureParam)]
        public bool HighResTexture { get; set; }

        [McpDescription(UMXPicoBerryToolText.TPoseParam)]
        public bool TPose { get; set; }

        [McpDescription(UMXPicoBerryToolText.PolygonCountParam)]
        public int PolygonCount { get; set; }

        [McpDescription(UMXPicoBerryToolText.NameParam)]
        public string Name { get; set; }

        [McpDescription(UMXPicoBerryToolText.PositionParam)]
        public string Position { get; set; }

        [McpDescription(UMXPicoBerryToolText.RotationParam)]
        public string Rotation { get; set; }

        [McpDescription(UMXPicoBerryToolText.ScaleParam)]
        public string Scale { get; set; }

        [McpDescription(UMXPicoBerryToolText.ParentParam)]
        public string Parent { get; set; }
    }

    public class PicoBerryStatusParams
    {
        [McpDescription(UMXPicoBerryToolText.SessionIdParam)]
        public string SessionId { get; set; }
    }

    public class PicoBerryWaitParams
    {
        [McpDescription(UMXPicoBerryToolText.SessionIdParam, Required = true)]
        public string SessionId { get; set; }

        [McpDescription(UMXPicoBerryToolText.TimeoutSecondsParam)]
        public int TimeoutSeconds { get; set; } = PicoBerryWaitRequest.DefaultTimeoutSeconds;
    }

    public class PicoBerryPlaceParams
    {
        [McpDescription(UMXPicoBerryToolText.SessionIdParam)]
        public string SessionId { get; set; }

        [McpDescription(UMXPicoBerryToolText.AssetIdParam)]
        public string AssetId { get; set; }

        [McpDescription(UMXPicoBerryToolText.NameParam)]
        public string Name { get; set; }

        [McpDescription(UMXPicoBerryToolText.PositionParam)]
        public string Position { get; set; }

        [McpDescription(UMXPicoBerryToolText.RotationParam)]
        public string Rotation { get; set; }

        [McpDescription(UMXPicoBerryToolText.ScaleParam)]
        public string Scale { get; set; }

        [McpDescription(UMXPicoBerryToolText.ParentParam)]
        public string Parent { get; set; }
    }

    public class PicoBerryListParams
    {
        [McpDescription(UMXPicoBerryToolText.QueryParam)]
        public string Query { get; set; }

        [McpDescription(UMXPicoBerryToolText.PageParam)]
        public int Page { get; set; } = 1;

        [McpDescription(UMXPicoBerryToolText.LimitParam)]
        public int Limit { get; set; } = PicoBerryListRequest.DefaultLimit;
    }

    // Unity.AI.MCP 어댑터. 프로토콜 변환만 담당하고 실제 실행은 Core 의 PicoBerry*Operation 으로 위임.
    [McpTool(
        name: "umx_picoberry_generate",
        description: UMXPicoBerryToolText.GenerateDescription,
        title: "UModelerX: PicoBerry Generate")]
    public class PicoBerryGenerateCommand : IUnityMcpTool<PicoBerryGenerateParams>
    {
        public Task<object> ExecuteAsync(PicoBerryGenerateParams parameters)
        {
            parameters ??= new PicoBerryGenerateParams();

            var buildError = UMXPicoBerryRequestBuilder.BuildGenerate(
                prompt: parameters.Prompt,
                imagePath: parameters.ImagePath,
                model: parameters.Model,
                texture: parameters.Texture,
                highResTexture: parameters.HighResTexture,
                tPose: parameters.TPose,
                polygonCount: parameters.PolygonCount,
                name: parameters.Name,
                position: parameters.Position,
                rotation: parameters.Rotation,
                scale: parameters.Scale,
                parent: parameters.Parent,
                out var request);

            if (buildError != null) return Task.FromResult(ToResponse(buildError));

            return Task.FromResult(ToResponse(PicoBerryGenerateOperation.Execute(request)));
        }

        internal static object ToResponse(UMXMcpResult result)
        {
            return result.Success
                ? Response.Success(result.Message, result.Data)
                : Response.Error(result.Message);
        }
    }

    [McpTool(
        name: "umx_picoberry_status",
        description: UMXPicoBerryToolText.StatusDescription,
        title: "UModelerX: PicoBerry Status")]
    public class PicoBerryStatusCommand : IUnityMcpTool<PicoBerryStatusParams>
    {
        public Task<object> ExecuteAsync(PicoBerryStatusParams parameters)
        {
            parameters ??= new PicoBerryStatusParams();
            var request = new PicoBerryStatusRequest { SessionId = parameters.SessionId };
            return Task.FromResult(
                PicoBerryGenerateCommand.ToResponse(PicoBerryStatusOperation.Execute(request)));
        }
    }

    [McpTool(
        name: "umx_picoberry_wait",
        description: UMXPicoBerryToolText.WaitDescription,
        title: "UModelerX: PicoBerry Wait")]
    public class PicoBerryWaitCommand : IUnityMcpTool<PicoBerryWaitParams>
    {
        public async Task<object> ExecuteAsync(PicoBerryWaitParams parameters)
        {
            parameters ??= new PicoBerryWaitParams();
            var request = new PicoBerryWaitRequest
            {
                SessionId = parameters.SessionId,
                TimeoutSeconds = parameters.TimeoutSeconds > 0
                    ? parameters.TimeoutSeconds
                    : PicoBerryWaitRequest.DefaultTimeoutSeconds,
            };
            var result = await PicoBerryWaitOperation.ExecuteAsync(request);
            return PicoBerryGenerateCommand.ToResponse(result);
        }
    }

    [McpTool(
        name: "umx_picoberry_place",
        description: UMXPicoBerryToolText.PlaceDescription,
        title: "UModelerX: PicoBerry Place")]
    public class PicoBerryPlaceCommand : IUnityMcpTool<PicoBerryPlaceParams>
    {
        public async Task<object> ExecuteAsync(PicoBerryPlaceParams parameters)
        {
            parameters ??= new PicoBerryPlaceParams();

            var buildError = UMXPicoBerryRequestBuilder.BuildPlace(
                sessionId: parameters.SessionId,
                assetId: parameters.AssetId,
                name: parameters.Name,
                position: parameters.Position,
                rotation: parameters.Rotation,
                scale: parameters.Scale,
                parent: parameters.Parent,
                out var request);

            if (buildError != null) return PicoBerryGenerateCommand.ToResponse(buildError);

            var result = await PicoBerryPlaceOperation.ExecuteAsync(request);
            return PicoBerryGenerateCommand.ToResponse(result);
        }
    }

    [McpTool(
        name: "umx_picoberry_list",
        description: UMXPicoBerryToolText.ListDescription,
        title: "UModelerX: PicoBerry List")]
    public class PicoBerryListCommand : IUnityMcpTool<PicoBerryListParams>
    {
        public async Task<object> ExecuteAsync(PicoBerryListParams parameters)
        {
            parameters ??= new PicoBerryListParams();
            var request = new PicoBerryListRequest
            {
                Query = parameters.Query,
                Page = parameters.Page,
                Limit = parameters.Limit > 0 ? parameters.Limit : PicoBerryListRequest.DefaultLimit,
            };
            var result = await PicoBerryListOperation.ExecuteAsync(request);
            return PicoBerryGenerateCommand.ToResponse(result);
        }
    }
}
